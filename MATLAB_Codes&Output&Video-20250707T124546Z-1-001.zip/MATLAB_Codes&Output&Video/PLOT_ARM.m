function PLOT_ARM(THETA_1, THETA_2, THETA_3, AX)
   L_1 = 100;
   L_2 = 65;
   A_1 = DH_TRANSFORM(0, 90, 0, THETA_1);
   A_2 = DH_TRANSFORM(L_1, 0, 0, THETA_2);
   A_3 = DH_TRANSFORM(L_2, 0, 0, THETA_3);
   T_0 = eye(4);
   P_0 = T_0(1:3, 4);
   T_1 = T_0 * A_1; P_1 = T_1(1:3, 4);
   T_2 = T_1 * A_2; P_2 = T_2(1:3, 4);
   T_3 = T_2 * A_3; P_3 = T_3(1:3, 4);
   PTS = [P_0, P_1, P_2, P_3];
   plot3(AX, PTS(1,:), PTS(2,:), PTS(3,:), '-o', 'LineWidth', 2, 'MarkerSize', 6);
   hold(AX, 'on');
   plot3(AX, P_3(1), P_3(2), P_3(3), 'rs', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
   hold(AX, 'off');
   xlabel(AX, 'X Axis (mm)');
   ylabel(AX, 'Y Axis (mm)');
   zlabel(AX, 'Z Axis (mm)');
   title(AX, '3-DOF Robot Arm Configuration');
   grid(AX, 'on');
   axis(AX, 'equal');
   xlim(AX, [-200, 200]);
   ylim(AX, [-200, 200]);
   zlim(AX, [-50, 200]);
end
