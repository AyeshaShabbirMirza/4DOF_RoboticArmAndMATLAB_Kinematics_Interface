function [T_04, POS] = FKINE(THETA_1, THETA_2, THETA_3)
   L_1 = 100;
   L_2 = 65;
   A_1 = DH_TRANSFORM(0, 90, 0, THETA_1);
   A_2 = DH_TRANSFORM(L_1, 0, 0, THETA_2);
   A_3 = DH_TRANSFORM(L_2, 0, 0, THETA_3);
   T_04 = A_1 * A_2 * A_3;
   POS = T_04(1:3, 4);
end
