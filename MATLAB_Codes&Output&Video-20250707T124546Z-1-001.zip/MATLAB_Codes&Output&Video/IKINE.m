function [THETA_1, THETA_2, THETA_3, SUCCESS] = IKINE(X, Y, Z)
   L_1 = 100;
   L_2 = 65;
   THETA_1 = atan2(Y, X);
   R = hypot(X, Y);
   S = Z;
   D = (R^2 + S^2 - L_1^2 - L_2^2) / (2 * L_1 * L_2);
   if abs(D) > 1
       SUCCESS = false;
       THETA_1 = 0; THETA_2 = 0; THETA_3 = 0;
       return;
   end
   THETA_3 = atan2(sqrt(1 - D^2), D);
   K_1 = L_1 + L_2 * cos(THETA_3);
   K_2 = L_2 * sin(THETA_3);
   THETA_2 = atan2(S, R) - atan2(K_2, K_1);
   SUCCESS = true;
   THETA_1 = rad2deg(THETA_1);
   THETA_2 = rad2deg(THETA_2);
   THETA_3 = rad2deg(THETA_3);
end
