clc; clear;
TARGETS = [...
   165, 0, 0;
   100, 50, 20;
   80, -40, 30;
   50, 10, 60;
   120, 0, -10;
];
N_POSES = size(TARGETS, 1);
ERRORS = zeros(N_POSES, 1);
figure('Name', 'FK/IK Accuracy', 'Position', [100, 100, 1200, 700]);
for I = 1:N_POSES
   X = TARGETS(I, 1);
   Y = TARGETS(I, 2);
   Z = TARGETS(I, 3);
   [TH1, TH2, TH3, SUCCESS] = IKINE(X, Y, Z);
   if ~SUCCESS
       fprintf('Pose %d: Target [%.1f, %.1f, %.1f] out of reach!\n', I, X, Y, Z);
       ERRORS(I) = NaN;
       continue;
   end
   [~, POS_EST] = FKINE(TH1, TH2, TH3);
   X_HAT = POS_EST(1); Y_HAT = POS_EST(2); Z_HAT = POS_EST(3);
   ERRORS(I) = norm([X - X_HAT, Y - Y_HAT, Z - Z_HAT]);
   AX = subplot(2, 3, I);
   PLOT_ARM(TH1, TH2, TH3, AX);
   hold(AX, 'on');
   plot3(AX, X, Y, Z, 'mx', 'MarkerSize', 12, 'LineWidth', 2);
   hold(AX, 'off');
   title(AX, sprintf('Pose %d: Error = %.2f mm', I, ERRORS(I)));
   xlabel(AX, 'X (mm)\newline');
   ylabel(AX, 'Y (mm)\newline');
   zlabel(AX, 'Z (mm)');
   view(AX, [45 30]); 
end
fprintf('\nPose  Error (mm)\n');
for I = 1:N_POSES
   fprintf('%2d    %7.2f\n', I, ERRORS(I));
end
fprintf('Mean Error = %.2f mm\n', nanmean(ERRORS));


