function A = DH_TRANSFORM(A_, ALPHA_DEG, D, THETA_DEG)
   ALPHA = deg2rad(ALPHA_DEG);
   THETA = deg2rad(THETA_DEG);
   A = [ cos(THETA), -sin(THETA)*cos(ALPHA), sin(THETA)*sin(ALPHA), A_*cos(THETA);
         sin(THETA),  cos(THETA)*cos(ALPHA), -cos(THETA)*sin(ALPHA), A_*sin(THETA);
         0,           sin(ALPHA),            cos(ALPHA),             D;
         0,           0,                     0,                      1 ];
end
